def log_softmax(input: Tensor,
    dim: Optional[int]=None,
    _stacklevel: int=3,
    dtype: Optional[int]=None) -> Tensor:
  _0 = __torch__.torch.nn.functional._get_softmax_dim
  if torch.__is__(dim, None):
    dim1 = _0("log_softmax", torch.dim(input), _stacklevel, )
    dim0 = dim1
  else:
    dim0 = unchecked_cast(int, dim)
  if torch.__is__(dtype, None):
    ret0 = torch.log_softmax(input, dim0, None)
    ret = ret0
  else:
    dtype0 = unchecked_cast(int, dtype)
    ret1 = torch.log_softmax(input, dim0, dtype0)
    ret = ret1
  return ret
def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    result = torch.relu_(input)
  else:
    result = torch.relu(input)
  return result
def linear(input: Tensor,
    weight: Tensor,
    bias: Optional[Tensor]=None) -> Tensor:
  if torch.eq(torch.dim(input), 2):
    _1 = torch.__isnot__(bias, None)
  else:
    _1 = False
  if _1:
    bias0 = unchecked_cast(Tensor, bias)
    ret2 = torch.addmm(bias0, input, torch.t(weight), beta=1, alpha=1)
    ret = ret2
  else:
    output = torch.matmul(input, torch.t(weight))
    if torch.__isnot__(bias, None):
      bias1 = unchecked_cast(Tensor, bias)
      output1 = torch.add_(output, bias1, alpha=1)
      output0 = output1
    else:
      output0 = output
    ret = output0
  return ret
def dropout(input: Tensor,
    p: float=0.5,
    training: bool=True,
    inplace: bool=False) -> Tensor:
  if torch.lt(p, 0.):
    _2 = True
  else:
    _2 = torch.gt(p, 1.)
  if _2:
    ops.prim.RaiseException("Exception")
  else:
    pass
  if inplace:
    _3 = torch.dropout_(input, p, training)
  else:
    _3 = torch.dropout(input, p, training)
  return _3
def layer_norm(input: Tensor,
    normalized_shape: List[int],
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _4 = torch.layer_norm(input, normalized_shape, weight, bias, eps, True)
  return _4
def _pad(input: Tensor,
    pad: List[int],
    mode: str="constant",
    value: float=0.) -> Tensor:
  _5 = __torch__.torch.nn.functional._pad_circular
  _6 = uninitialized(Tensor)
  _7 = torch.eq(torch.remainder(torch.len(pad), 2), 0)
  if _7:
    pass
  else:
    ops.prim.RaiseException("Exception")
  _8 = torch.le(torch.floordiv(torch.len(pad), 2), torch.dim(input))
  if _8:
    pass
  else:
    ops.prim.RaiseException("Exception")
  if torch.eq(mode, "constant"):
    _10 = torch.constant_pad_nd(input, pad, value)
    _9 = _10
  else:
    if torch.eq(value, 0):
      pass
    else:
      ops.prim.RaiseException("Exception")
    if torch.eq(torch.dim(input), 3):
      if torch.eq(torch.len(pad), 2):
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq(mode, "reflect"):
        _13 = torch.reflection_pad1d(input, pad)
        _12 = _13
      else:
        if torch.eq(mode, "replicate"):
          _15 = torch.replication_pad1d(input, pad)
          _14 = _15
        else:
          if torch.eq(mode, "circular"):
            _16 = _5(input, pad, )
          else:
            ops.prim.RaiseException("Exception")
            _16 = _6
          _14 = _16
        _12 = _14
      _11 = _12
    else:
      if torch.eq(torch.dim(input), 4):
        if torch.eq(torch.len(pad), 4):
          pass
        else:
          ops.prim.RaiseException("Exception")
        if torch.eq(mode, "reflect"):
          _19 = torch.reflection_pad2d(input, pad)
          _18 = _19
        else:
          if torch.eq(mode, "replicate"):
            _21 = torch.replication_pad2d(input, pad)
            _20 = _21
          else:
            if torch.eq(mode, "circular"):
              _22 = _5(input, pad, )
            else:
              ops.prim.RaiseException("Exception")
              _22 = _6
            _20 = _22
          _18 = _20
        _17 = _18
      else:
        if torch.eq(torch.dim(input), 5):
          if torch.eq(torch.len(pad), 6):
            pass
          else:
            ops.prim.RaiseException("Exception")
          if torch.eq(mode, "reflect"):
            ops.prim.RaiseException("Exception")
            _24 = _6
          else:
            if torch.eq(mode, "replicate"):
              _26 = torch.replication_pad3d(input, pad)
              _25 = _26
            else:
              _27 = torch.eq(mode, "circular")
              if _27:
                _28 = _5(input, pad, )
              else:
                ops.prim.RaiseException("Exception")
                _28 = _6
              _25 = _28
            _24 = _25
          _23 = _24
        else:
          ops.prim.RaiseException("Exception")
          _23 = _6
        _17 = _23
      _11 = _17
    _9 = _11
  return _9
def glu(input: Tensor,
    dim: int=-1) -> Tensor:
  if torch.eq(torch.dim(input), 0):
    ops.prim.RaiseException("Exception")
  else:
    pass
  return torch.glu(input, dim)
def embedding(input: Tensor,
    weight: Tensor,
    padding_idx: Optional[int]=None,
    max_norm: Optional[float]=None,
    norm_type: float=2.,
    scale_grad_by_freq: bool=False,
    sparse: bool=False) -> Tensor:
  if torch.__isnot__(padding_idx, None):
    padding_idx1 = unchecked_cast(int, padding_idx)
    if torch.gt(padding_idx1, 0):
      _29 = torch.lt(padding_idx1, torch.size(weight, 0))
      if _29:
        pass
      else:
        ops.prim.RaiseException("Exception")
      padding_idx2 = padding_idx1
    else:
      if torch.lt(padding_idx1, 0):
        _30 = torch.neg(torch.size(weight, 0))
        if torch.ge(padding_idx1, _30):
          pass
        else:
          ops.prim.RaiseException("Exception")
        padding_idx4 = torch.add(torch.size(weight, 0), padding_idx1)
        padding_idx3 = padding_idx4
      else:
        padding_idx3 = padding_idx1
      padding_idx2 = padding_idx3
    padding_idx0 = padding_idx2
  else:
    padding_idx0 = -1
  if torch.__isnot__(max_norm, None):
    input1 = torch.contiguous(input, memory_format=0)
    input0 = input1
  else:
    input0 = input
  _31 = torch.embedding(weight, input0, padding_idx0, scale_grad_by_freq, sparse)
  return _31
def ctc_loss(log_probs: Tensor,
    targets: Tensor,
    input_lengths: Tensor,
    target_lengths: Tensor,
    blank: int=0,
    reduction: str="mean",
    zero_infinity: bool=False) -> Tensor:
  _32 = __torch__.torch.nn._reduction.get_enum
  _33 = torch.ctc_loss(log_probs, targets, input_lengths, target_lengths, blank, _32(reduction, ), zero_infinity)
  return _33
def kl_div(input: Tensor,
    target: Tensor,
    size_average: Optional[bool]=None,
    reduce: Optional[bool]=None,
    reduction: str="mean",
    log_target: bool=False) -> Tensor:
  _34 = __torch__.torch.nn._reduction.legacy_get_enum
  _35 = "reduction: \'mean\' divides the total loss by both the batch size and the support size.\'batchmean\' divides only by the batch size, and aligns with the KL div math definition.\'mean\' will be changed to behave the same as \'batchmean\' in the next major release."
  _36 = __torch__.torch.nn._reduction.get_enum
  if torch.__isnot__(size_average, None):
    _37, size_average0 = True, unchecked_cast(bool, size_average)
  else:
    _37, size_average0 = torch.__isnot__(reduce, None), size_average
  if _37:
    reduction_enum = _34(size_average0, reduce, True, )
  else:
    if torch.eq(reduction, "mean"):
      torch.warn(_35, 2)
    else:
      pass
    if torch.eq(reduction, "batchmean"):
      reduction_enum0 = _36("sum", )
    else:
      reduction_enum0 = _36(reduction, )
    reduction_enum = reduction_enum0
  reduced = torch.kl_div(input, target, reduction_enum, log_target=log_target)
  if torch.eq(reduction, "batchmean"):
    _38 = torch.ne(torch.dim(input), 0)
  else:
    _38 = False
  if _38:
    reduced1 = torch.div(reduced, (torch.size(input))[0])
    reduced0 = reduced1
  else:
    reduced0 = reduced
  return reduced0
def _get_softmax_dim(name: str,
    ndim: int,
    stacklevel: int) -> int:
  _39 = "Implicit dimension choice for {} has been deprecated. Change the call to include dim=X as an argument."
  torch.warn(torch.format(_39, name), stacklevel)
  if torch.eq(ndim, 0):
    _40 = True
  else:
    _40 = torch.eq(ndim, 1)
  if _40:
    _41 = True
  else:
    _41 = torch.eq(ndim, 3)
  if _41:
    ret = 0
  else:
    ret = 1
  return ret
def _pad_circular(input: Tensor,
    padding: List[int]) -> Tensor:
  _42 = torch.slice(input, 0, 0, 9223372036854775807, 1)
  _43 = torch.slice(_42, 1, 0, 9223372036854775807, 1)
  _44 = torch.slice(_43, 2, 0, padding[-1], 1)
  input2 = torch.cat([input, _44], 2)
  _45 = torch.slice(input2, 0, 0, 9223372036854775807, 1)
  _46 = torch.slice(_45, 1, 0, 9223372036854775807, 1)
  _47 = torch.neg(torch.add(padding[-1], padding[-2]))
  _48 = torch.slice(_46, 2, _47, torch.neg(padding[-1]), 1)
  input3 = torch.cat([_48, input2], 2)
  if torch.gt(torch.len(padding), 2):
    _49 = torch.slice(input3, 0, 0, 9223372036854775807, 1)
    _50 = torch.slice(_49, 1, 0, 9223372036854775807, 1)
    _51 = torch.slice(_50, 2, 0, 9223372036854775807, 1)
    _52 = torch.slice(_51, 3, 0, padding[-3], 1)
    input5 = torch.cat([input3, _52], 3)
    _53 = torch.slice(input5, 0, 0, 9223372036854775807, 1)
    _54 = torch.slice(_53, 1, 0, 9223372036854775807, 1)
    _55 = torch.slice(_54, 2, 0, 9223372036854775807, 1)
    _56 = torch.neg(torch.add(padding[-3], padding[-4]))
    _57 = torch.slice(_55, 3, _56, torch.neg(padding[-3]), 1)
    input4 = torch.cat([_57, input5], 3)
  else:
    input4 = input3
  if torch.gt(torch.len(padding), 4):
    _58 = torch.slice(input4, 0, 0, 9223372036854775807, 1)
    _59 = torch.slice(_58, 1, 0, 9223372036854775807, 1)
    _60 = torch.slice(_59, 2, 0, 9223372036854775807, 1)
    _61 = torch.slice(_60, 3, 0, 9223372036854775807, 1)
    _62 = torch.slice(_61, 4, 0, padding[-5], 1)
    input7 = torch.cat([input4, _62], 4)
    _63 = torch.slice(input7, 0, 0, 9223372036854775807, 1)
    _64 = torch.slice(_63, 1, 0, 9223372036854775807, 1)
    _65 = torch.slice(_64, 2, 0, 9223372036854775807, 1)
    _66 = torch.slice(_65, 3, 0, 9223372036854775807, 1)
    _67 = torch.neg(torch.add(padding[-5], padding[-6]))
    _68 = torch.slice(_66, 4, _67, torch.neg(padding[-5]), 1)
    input6 = torch.cat([_68, input7], 4)
  else:
    input6 = input4
  return input6
