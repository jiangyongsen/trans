def subsequent_mask(size: int,
    device: Device=torch.device("cpu")) -> Tensor:
  ret = torch.ones([size, size], dtype=11, layout=None, device=device, pin_memory=None)
  return torch.tril(ret, 0, out=ret)
def mask_finished_scores(score: Tensor,
    flag: Tensor) -> Tensor:
  beam_size = torch.size(score, -1)
  zero_mask = torch.zeros_like(flag, dtype=11, layout=None, device=None, pin_memory=None, memory_format=None)
  if torch.gt(beam_size, 1):
    _0 = torch.repeat(flag, [1, torch.sub(beam_size, 1)])
    unfinished0 = torch.cat([zero_mask, _0], 1)
    _1 = torch.repeat(zero_mask, [1, torch.sub(beam_size, 1)])
    unfinished, finished = unfinished0, torch.cat([flag, _1], 1)
  else:
    unfinished, finished = zero_mask, flag
  _2 = torch.masked_fill_(score, unfinished, -inf)
  _3 = torch.masked_fill_(score, finished, 0)
  return score
def mask_finished_preds(pred: Tensor,
    flag: Tensor,
    eos: int) -> Tensor:
  beam_size = torch.size(pred, -1)
  finished = torch.repeat(flag, [1, beam_size])
  _4 = torch.masked_fill_(pred, finished, eos)
  return _4
def make_pad_mask(lengths: Tensor) -> Tensor:
  batch_size = torch.size(lengths, 0)
  max_len = int(torch.item(torch.max(lengths)))
  seq_range = torch.arange(0, max_len, dtype=4, layout=None, device=ops.prim.device(lengths), pin_memory=None)
  seq_range_expand = torch.expand(torch.unsqueeze(seq_range, 0), [batch_size, max_len], implicit=False)
  seq_length_expand = torch.unsqueeze(lengths, -1)
  mask = torch.ge(seq_range_expand, seq_length_expand)
  return mask
def add_optional_chunk_mask(xs: Tensor,
    masks: Tensor,
    use_dynamic_chunk: bool,
    decoding_chunk_size: int,
    static_chunk_size: int) -> Tensor:
  _5 = __torch__.wenet.utils.mask.subsequent_chunk_mask
  if use_dynamic_chunk:
    max_len = torch.size(xs, 1)
    if torch.lt(decoding_chunk_size, 0):
      chunk_size = max_len
    else:
      if torch.gt(decoding_chunk_size, 0):
        chunk_size0 = decoding_chunk_size
      else:
        _6 = torch.randint(1, max_len, [1], dtype=None, layout=None, device=None, pin_memory=None)
        chunk_size1 = torch.item(_6)
        _7 = torch.gt(chunk_size1, torch.floordiv(max_len, 2))
        if _7:
          chunk_size2 = max_len
        else:
          _8 = torch.remainder(chunk_size1, 25)
          chunk_size2 = torch.add(_8, 1)
        chunk_size0 = chunk_size2
      chunk_size = chunk_size0
    _9 = torch.size(xs, 1)
    _10 = ops.prim.device(xs)
    chunk_masks0 = _5(_9, int(chunk_size), _10, )
    chunk_masks1 = torch.unsqueeze(chunk_masks0, 0)
    chunk_masks = torch.__and__(masks, chunk_masks1)
  else:
    if torch.gt(static_chunk_size, 0):
      chunk_masks3 = _5(torch.size(xs, 1), static_chunk_size, ops.prim.device(xs), )
      chunk_masks4 = torch.unsqueeze(chunk_masks3, 0)
      chunk_masks5 = torch.__and__(masks, chunk_masks4)
      chunk_masks2 = chunk_masks5
    else:
      chunk_masks2 = masks
    chunk_masks = chunk_masks2
  return chunk_masks
def subsequent_chunk_mask(size: int,
    chunk_size: int,
    device: Device=torch.device("cpu")) -> Tensor:
  ret = torch.zeros([size, size], dtype=11, layout=None, device=device, pin_memory=None)
  for i in range(size):
    _11 = torch.add(torch.floordiv(i, chunk_size), 1)
    ending = ops.prim.min(torch.mul(_11, chunk_size), size)
    _12 = torch.slice(torch.select(ret, 0, i), 0, 0, ending, 1)
    _13 = torch.tensor(True, dtype=ops.prim.dtype(_12), device=ops.prim.device(_12), requires_grad=False)
    _14 = torch.copy_(_12, _13, False)
  return ret
