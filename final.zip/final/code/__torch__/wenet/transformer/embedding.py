class RelPositionalEncoding(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  d_model : int
  xscale : float
  max_len : int
  pe : Tensor
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  def forward(self: __torch__.wenet.transformer.embedding.RelPositionalEncoding,
    x: Tensor,
    offset: int=0) -> Tuple[Tensor, Tensor]:
    _0 = torch.lt(torch.add(offset, torch.size(x, 1)), self.max_len)
    if _0:
      pass
    else:
      ops.prim.RaiseException("Exception")
    _1 = torch.to(self.pe, ops.prim.device(x), None, False, False)
    self.pe = _1
    x0 = torch.mul(x, self.xscale)
    _2 = torch.slice(self.pe, 0, 0, 9223372036854775807, 1)
    _3 = torch.add(offset, torch.size(x0, 1))
    pos_emb = torch.slice(_2, 1, offset, _3, 1)
    _4 = ((self.dropout).forward(x0, ), (self.dropout).forward(pos_emb, ))
    return _4
  def position_encoding(self: __torch__.wenet.transformer.embedding.RelPositionalEncoding,
    size: int) -> Tensor:
    if torch.lt(size, self.max_len):
      pass
    else:
      ops.prim.RaiseException("Exception")
    _5 = self.dropout
    _6 = torch.slice(self.pe, 0, 0, 9223372036854775807, 1)
    _7 = (_5).forward(torch.slice(_6, 1, 0, size, 1), )
    return _7
class PositionalEncoding(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  d_model : int
  xscale : float
  max_len : int
  pe : Tensor
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  def forward(self: __torch__.wenet.transformer.embedding.PositionalEncoding,
    x: Tensor,
    offset: int=0) -> Tuple[Tensor, Tensor]:
    _8 = torch.lt(torch.add(offset, torch.size(x, 1)), self.max_len)
    if _8:
      pass
    else:
      ops.prim.RaiseException("Exception")
    _9 = torch.to(self.pe, ops.prim.device(x), None, False, False)
    self.pe = _9
    _10 = torch.slice(self.pe, 0, 0, 9223372036854775807, 1)
    pos_emb = torch.slice(_10, 1, offset, torch.add(offset, torch.size(x, 1)), 1)
    x1 = torch.add(torch.mul(x, self.xscale), pos_emb, alpha=1)
    _11 = ((self.dropout).forward(x1, ), (self.dropout).forward(pos_emb, ))
    return _11
