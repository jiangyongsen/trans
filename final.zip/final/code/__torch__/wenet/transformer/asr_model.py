class ASRModel(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  sos : int
  eos : int
  vocab_size : int
  ignore_id : int
  ctc_weight : float
  encoder : __torch__.wenet.transformer.encoder.ConformerEncoder
  decoder : __torch__.wenet.transformer.decoder.TransformerDecoder
  ctc : __torch__.wenet.transformer.ctc.CTC
  criterion_att : __torch__.wenet.transformer.label_smoothing_loss.LabelSmoothingLoss
  def forward(self: __torch__.wenet.transformer.asr_model.ASRModel,
    speech: Tensor,
    speech_lengths: Tensor,
    text: Tensor,
    text_lengths: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    _0 = torch.eq(torch.dim(text_lengths), 1)
    if _0:
      pass
    else:
      ops.prim.RaiseException("Exception")
    _1 = torch.eq((torch.size(speech))[0], (torch.size(speech_lengths))[0])
    if _1:
      _3 = torch.eq((torch.size(speech_lengths))[0], (torch.size(text))[0])
      _2 = _3
    else:
      _2 = False
    if _2:
      _5 = torch.eq((torch.size(text))[0], (torch.size(text_lengths))[0])
      _4 = _5
    else:
      _4 = False
    if _4:
      pass
    else:
      ops.prim.RaiseException("Exception")
    _6 = (self.encoder).forward(speech, speech_lengths, 0, )
    encoder_out, encoder_mask, = _6
    encoder_out_lens = torch.sum(torch.squeeze(encoder_mask, 1), [1], False, dtype=None)
    _7 = (self)._calc_att_loss(encoder_out, encoder_mask, text, text_lengths, )
    loss_att, acc_att, = _7
    loss_ctc = (self.ctc).forward(encoder_out, encoder_out_lens, text, text_lengths, )
    if torch.eq(self.ctc_weight, 0.):
      loss = loss_att
    else:
      if torch.eq(self.ctc_weight, 1.):
        loss0 = loss_ctc
      else:
        _8 = torch.mul(loss_ctc, self.ctc_weight)
        _9 = torch.mul(loss_att, torch.sub(1, self.ctc_weight))
        loss0 = torch.add(_8, _9, alpha=1)
      loss = loss0
    return (loss, loss_att, loss_ctc)
  def ctc_activation(self: __torch__.wenet.transformer.asr_model.ASRModel,
    xs: Tensor) -> Tensor:
    return (self.ctc).log_softmax(xs, )
  def eos_symbol(self: __torch__.wenet.transformer.asr_model.ASRModel) -> int:
    return self.eos
  def forward_attention_decoder(self: __torch__.wenet.transformer.asr_model.ASRModel,
    hyps: Tensor,
    hyps_lens: Tensor,
    encoder_out: Tensor) -> Tensor:
    _10 = __torch__.torch.nn.functional.log_softmax
    _11 = torch.eq(torch.size(encoder_out, 0), 1)
    if _11:
      pass
    else:
      ops.prim.RaiseException("Exception")
    num_hyps = torch.size(hyps, 0)
    _12 = torch.eq(torch.size(hyps_lens, 0), num_hyps)
    if _12:
      pass
    else:
      ops.prim.RaiseException("Exception")
    encoder_out0 = torch.repeat(encoder_out, [num_hyps, 1, 1])
    _13 = torch.size(encoder_out0, 1)
    _14 = ops.prim.device(encoder_out0)
    encoder_mask = torch.ones([num_hyps, 1, _13], dtype=11, layout=None, device=_14, pin_memory=None)
    _15 = (self.decoder).forward(encoder_out0, encoder_mask, hyps, hyps_lens, )
    decoder_out, _16, = _15
    return _10(decoder_out, -1, 3, None, )
  def forward_encoder_chunk(self: __torch__.wenet.transformer.asr_model.ASRModel,
    xs: Tensor,
    subsampling_cache: Optional[Tensor]=None,
    elayers_output_cache: Optional[List[Tensor]]=None,
    conformer_cnn_cache: Optional[List[Tensor]]=None) -> Tuple[Tensor, Tensor, List[Tensor], List[Tensor]]:
    _17 = (self.encoder).forward_chunk(xs, subsampling_cache, elayers_output_cache, conformer_cnn_cache, )
    return _17
  def recognize(self: __torch__.wenet.transformer.asr_model.ASRModel,
    speech: Tensor,
    speech_lengths: Tensor,
    beam_size: int=10,
    decoding_chunk_size: int=-1,
    simulate_streaming: bool=False) -> Tensor:
    _18 = __torch__.wenet.utils.mask.subsequent_mask
    _19 = __torch__.wenet.utils.mask.mask_finished_scores
    _20 = __torch__.wenet.utils.mask.mask_finished_preds
    _21 = torch.eq((torch.size(speech))[0], (torch.size(speech_lengths))[0])
    if _21:
      pass
    else:
      ops.prim.RaiseException("Exception")
    if torch.ne(decoding_chunk_size, 0):
      pass
    else:
      ops.prim.RaiseException("Exception")
    device = ops.prim.device(speech)
    batch_size = (torch.size(speech))[0]
    if simulate_streaming:
      _22 = torch.gt(decoding_chunk_size, 0)
    else:
      _22 = False
    if _22:
      _23 = (self.encoder).forward_chunk_by_chunk(speech, decoding_chunk_size, )
      encoder_out1, encoder_mask0, = _23
      encoder_out, encoder_mask = encoder_out1, encoder_mask0
    else:
      _24 = (self.encoder).forward(speech, speech_lengths, decoding_chunk_size, )
      encoder_out2, encoder_mask1, = _24
      encoder_out, encoder_mask = encoder_out2, encoder_mask1
    maxlen = torch.size(encoder_out, 1)
    encoder_dim = torch.size(encoder_out, 2)
    running_size = torch.mul(batch_size, beam_size)
    _25 = torch.repeat(torch.unsqueeze(encoder_out, 1), [1, beam_size, 1, 1])
    encoder_out3 = torch.view(_25, [running_size, maxlen, encoder_dim])
    _26 = torch.repeat(torch.unsqueeze(encoder_mask, 1), [1, beam_size, 1, 1])
    encoder_mask2 = torch.view(_26, [running_size, 1, maxlen])
    _27 = torch.ones([running_size, 1], dtype=4, layout=None, device=device, pin_memory=None)
    hyps = torch.fill_(_27, self.sos)
    _28 = [0.]
    _29 = torch.mul([-inf], torch.sub(beam_size, 1))
    scores = torch.tensor(torch.add(_28, _29), dtype=6, device=None, requires_grad=False)
    _30 = torch.to(scores, device, None, False, False)
    _31 = torch.unsqueeze(torch.repeat(_30, [batch_size]), 1)
    scores0 = torch.to(_31, device, None, False, False)
    end_flag = torch.zeros_like(scores0, dtype=11, layout=None, device=device, pin_memory=None, memory_format=None)
    _32 = torch.__range_length(1, torch.add(maxlen, 1), 1)
    scores1 = scores0
    hyps0 = hyps
    cache: Optional[List[Tensor]] = None
    end_flag0 = end_flag
    _33 = 0
    _34 = torch.gt(_32, 0)
    while _34:
      i = torch.__derive_index(_33, 1, 1)
      _35 = torch.eq(torch.sum(end_flag0, dtype=None), running_size)
      if bool(_35):
        _36, _37, _38, _39, _40 = False, scores1, hyps0, cache, end_flag0
      else:
        _41 = torch.unsqueeze(_18(i, torch.device("cpu"), ), 0)
        _42 = torch.repeat(_41, [running_size, 1, 1])
        hyps_mask = torch.to(_42, device, None, False, False)
        _43 = (self.decoder).forward_one_step(encoder_out3, encoder_mask2, hyps0, hyps_mask, cache, )
        logp, cache0, = _43
        top_k_logp, top_k_index = torch.topk(logp, beam_size, -1, True, True)
        top_k_logp0 = _19(top_k_logp, end_flag0, )
        top_k_index0 = _20(top_k_index, end_flag0, self.eos, )
        scores2 = torch.add(scores1, top_k_logp0, alpha=1)
        _44 = [batch_size, torch.mul(beam_size, beam_size)]
        scores3 = torch.view(scores2, _44)
        scores4, offset_k_index = torch.topk(scores3, beam_size, -1, True, True)
        scores5 = torch.view(scores4, [-1, 1])
        _45 = torch.arange(batch_size, dtype=None, layout=None, device=device, pin_memory=None)
        base_k_index = torch.repeat(torch.view(_45, [-1, 1]), [1, beam_size])
        _46 = torch.mul(base_k_index, beam_size)
        base_k_index0 = torch.mul(_46, beam_size)
        _47 = torch.view(base_k_index0, [-1])
        _48 = torch.view(offset_k_index, [-1])
        best_k_index = torch.add(_47, _48, alpha=1)
        best_k_pred = torch.index_select(torch.view(top_k_index0, [-1]), -1, best_k_index)
        best_hyps_index = torch.floor_divide(best_k_index, beam_size)
        last_best_k_hyps = torch.index_select(hyps0, 0, best_hyps_index)
        _49 = torch.view(best_k_pred, [-1, 1])
        hyps1 = torch.cat([last_best_k_hyps, _49], 1)
        _50 = torch.slice(hyps1, 0, 0, 9223372036854775807, 1)
        _51 = torch.eq(torch.select(_50, 1, -1), self.eos)
        _36, _37, _38, _39, _40 = True, scores5, hyps1, cache0, torch.view(_51, [-1, 1])
      _52 = torch.add(_33, 1)
      _53 = torch.__and__(torch.lt(_52, _32), _36)
      _34, scores1, hyps0, cache, end_flag0, _33 = _53, _37, _38, _39, _40, _52
    scores6 = torch.view(scores1, [batch_size, beam_size])
    best_index = torch.to(torch.argmax(scores6, -1, False), 4, False, False, None)
    _54 = torch.arange(batch_size, dtype=4, layout=None, device=device, pin_memory=None)
    best_hyps_index0 = torch.add(best_index, torch.mul(_54, beam_size), alpha=1)
    best_hyps = torch.index_select(hyps0, 0, best_hyps_index0)
    _55 = torch.slice(best_hyps, 0, 0, 9223372036854775807, 1)
    best_hyps0 = torch.slice(_55, 1, 1, 9223372036854775807, 1)
    return best_hyps0
  def right_context(self: __torch__.wenet.transformer.asr_model.ASRModel) -> int:
    return self.encoder.embed.right_context
  def sos_symbol(self: __torch__.wenet.transformer.asr_model.ASRModel) -> int:
    return self.sos
  def subsampling_rate(self: __torch__.wenet.transformer.asr_model.ASRModel) -> int:
    return self.encoder.embed.subsampling_rate
  def _calc_att_loss(self: __torch__.wenet.transformer.asr_model.ASRModel,
    encoder_out: Tensor,
    encoder_mask: Tensor,
    ys_pad: Tensor,
    ys_pad_lens: Tensor) -> Tuple[Tensor, float]:
    _56 = __torch__.wenet.utils.common.add_sos_eos
    _57 = __torch__.wenet.utils.common.th_accuracy
    _58 = _56(ys_pad, self.sos, self.eos, self.ignore_id, )
    ys_in_pad, ys_out_pad, = _58
    ys_in_lens = torch.add(ys_pad_lens, 1, 1)
    _59 = (self.decoder).forward(encoder_out, encoder_mask, ys_in_pad, ys_in_lens, )
    decoder_out, _60, = _59
    loss_att = (self.criterion_att).forward(decoder_out, ys_out_pad, )
    _61 = torch.view(decoder_out, [-1, self.vocab_size])
    acc_att = _57(_61, ys_out_pad, self.ignore_id, )
    return (loss_att, acc_att)
