def add_sos_eos(ys_pad: Tensor,
    sos: int,
    eos: int,
    ignore_id: int) -> Tuple[Tensor, Tensor]:
  _sos = torch.tensor([sos], dtype=4, device=ops.prim.device(ys_pad), requires_grad=False)
  _eos = torch.tensor([eos], dtype=4, device=ops.prim.device(ys_pad), requires_grad=False)
  ys = annotate(List[Tensor], [])
  for _0 in range(torch.len(ys_pad)):
    y = torch.select(ys_pad, 0, _0)
    _1 = annotate(List[Optional[Tensor]], [torch.ne(y, ignore_id)])
    _2 = torch.append(ys, torch.index(y, _1))
  ys_in = annotate(List[Tensor], [])
  for _3 in range(torch.len(ys)):
    y0 = ys[_3]
    _4 = torch.append(ys_in, torch.cat([_sos, y0], 0))
  ys_out = annotate(List[Tensor], [])
  for _5 in range(torch.len(ys)):
    y1 = ys[_5]
    _6 = torch.append(ys_out, torch.cat([y1, _eos], 0))
  _7 = __torch__.wenet.utils.common.pad_list(ys_in, eos, )
  _8 = __torch__.wenet.utils.common.pad_list(ys_out, ignore_id, )
  return (_7, _8)
def th_accuracy(pad_outputs: Tensor,
    pad_targets: Tensor,
    ignore_label: int) -> float:
  _9 = [torch.size(pad_targets, 0), torch.size(pad_targets, 1), torch.size(pad_outputs, 1)]
  pad_pred = torch.argmax(torch.view(pad_outputs, _9), 2, False)
  mask = torch.ne(pad_targets, ignore_label)
  _10 = torch.masked_select(pad_pred, mask)
  _11 = torch.masked_select(pad_targets, mask)
  numerator = torch.sum(torch.eq(_10, _11), dtype=None)
  denominator = torch.sum(mask, dtype=None)
  _12 = torch.div(float(numerator), float(denominator))
  return _12
def pad_list(xs: List[Tensor],
    pad_value: int) -> Tensor:
  n_batch = torch.len(xs)
  _13 = annotate(List[int], [])
  for _14 in range(torch.len(xs)):
    x = xs[_14]
    _15 = torch.append(_13, torch.size(x, 0))
  max_len = ops.prim.max(_13)
  _16 = ops.prim.dtype(xs[0])
  _17 = ops.prim.device(xs[0])
  pad = torch.zeros([n_batch, max_len], dtype=_16, layout=None, device=_17, pin_memory=None)
  pad0 = torch.fill_(pad, pad_value)
  for i in range(n_batch):
    _18 = xs[i]
    _19 = torch.slice(torch.select(pad0, 0, i), 0, 0, torch.size(xs[i], 0), 1)
    _20 = torch.copy_(_19, _18, False)
  return pad0
