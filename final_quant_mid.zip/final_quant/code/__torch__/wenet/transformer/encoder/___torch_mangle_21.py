class ConformerEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _output_size : int
  normalize_before : bool
  static_chunk_size : int
  use_dynamic_chunk : bool
  global_cmvn : __torch__.wenet.transformer.cmvn.GlobalCMVN
  embed : __torch__.wenet.transformer.subsampling.___torch_mangle_16.Conv2dSubsampling4
  after_norm : __torch__.torch.nn.modules.normalization.LayerNorm
  encoders : __torch__.torch.nn.modules.container.___torch_mangle_20.ModuleList
  def forward(self: __torch__.wenet.transformer.encoder.___torch_mangle_21.ConformerEncoder,
    xs: Tensor,
    xs_lens: Tensor,
    decoding_chunk_size: int=0) -> Tuple[Tensor, Tensor]:
    _0 = __torch__.wenet.utils.mask.make_pad_mask
    _1 = __torch__.wenet.utils.mask.add_optional_chunk_mask
    masks = torch.bitwise_not(torch.unsqueeze(_0(xs_lens, ), 1))
    xs0 = (self.global_cmvn).forward(xs, )
    _2 = (self.embed).forward(xs0, masks, 0, )
    xs1, pos_emb, masks0, = _2
    chunk_masks = _1(xs1, masks0, self.use_dynamic_chunk, decoding_chunk_size, self.static_chunk_size, )
    _3 = self.encoders
    _4 = getattr(_3, "0")
    _5 = getattr(_3, "1")
    _6 = getattr(_3, "2")
    _7 = getattr(_3, "3")
    _8 = getattr(_3, "4")
    _9 = getattr(_3, "5")
    _10 = getattr(_3, "6")
    _11 = getattr(_3, "7")
    _12 = getattr(_3, "8")
    _13 = (_4).forward(xs1, chunk_masks, pos_emb, None, None, )
    xs2, chunk_masks0, _14, = _13
    _15 = (_5).forward(xs2, chunk_masks0, pos_emb, None, None, )
    xs3, chunk_masks1, _16, = _15
    _17 = (_6).forward(xs3, chunk_masks1, pos_emb, None, None, )
    xs4, chunk_masks2, _18, = _17
    _19 = (_7).forward(xs4, chunk_masks2, pos_emb, None, None, )
    xs5, chunk_masks3, _20, = _19
    _21 = (_8).forward(xs5, chunk_masks3, pos_emb, None, None, )
    xs6, chunk_masks4, _22, = _21
    _23 = (_9).forward(xs6, chunk_masks4, pos_emb, None, None, )
    xs7, chunk_masks5, _24, = _23
    _25 = (_10).forward(xs7, chunk_masks5, pos_emb, None, None, )
    xs8, chunk_masks6, _26, = _25
    _27 = (_11).forward(xs8, chunk_masks6, pos_emb, None, None, )
    xs9, chunk_masks7, _28, = _27
    _29 = (_12).forward(xs9, chunk_masks7, pos_emb, None, None, )
    xs10, chunk_masks8, _30, = _29
    if self.normalize_before:
      xs11 = (self.after_norm).forward(xs10, )
    else:
      xs11 = xs10
    return (xs11, masks0)
  def forward_chunk(self: __torch__.wenet.transformer.encoder.___torch_mangle_21.ConformerEncoder,
    xs: Tensor,
    subsampling_cache: Optional[Tensor]=None,
    elayers_output_cache: Optional[List[Tensor]]=None,
    conformer_cnn_cache: Optional[List[Tensor]]=None) -> Tuple[Tensor, Tensor, List[Tensor], List[Tensor]]:
    _31 = uninitialized(List[Tensor])
    if torch.eq(torch.size(xs, 0), 1):
      pass
    else:
      ops.prim.RaiseException("Exception")
    _32 = torch.__is__(subsampling_cache, None)
    if _32:
      offset, subsampling_cache0, elayers_output_cache0 = 0, subsampling_cache, elayers_output_cache
    else:
      subsampling_cache1 = unchecked_cast(Tensor, subsampling_cache)
      _33 = torch.__isnot__(elayers_output_cache, None)
      if _33:
        elayers_output_cache2 = unchecked_cast(List[Tensor], elayers_output_cache)
        elayers_output_cache1 = elayers_output_cache2
      else:
        ops.prim.RaiseException("Exception")
        elayers_output_cache1 = _31
      offset, subsampling_cache0, elayers_output_cache0 = torch.size(subsampling_cache1, 1), subsampling_cache1, elayers_output_cache1
    _34 = torch.size(xs, 1)
    _35 = ops.prim.device(xs)
    tmp_masks = torch.ones([1, _34], dtype=11, layout=None, device=_35, pin_memory=None)
    tmp_masks0 = torch.unsqueeze(tmp_masks, 1)
    xs12 = (self.global_cmvn).forward(xs, )
    _36 = (self.embed).forward(xs12, tmp_masks0, offset, )
    xs13, pos_emb, _37, = _36
    _38 = torch.__isnot__(subsampling_cache0, None)
    if _38:
      subsampling_cache2 = unchecked_cast(Tensor, subsampling_cache0)
      xs15 = torch.cat([subsampling_cache2, xs13], 1)
      xs14 = xs15
    else:
      xs14 = xs13
    pos_emb0 = (self.embed).position_encoding(torch.size(xs14, 1), )
    _39 = torch.size(xs14, 1)
    _40 = ops.prim.device(xs14)
    masks = torch.ones([1, _39], dtype=11, layout=None, device=_40, pin_memory=None)
    masks1 = torch.unsqueeze(masks, 1)
    r_elayers_output_cache = annotate(List[Tensor], [])
    r_conformer_cnn_cache = annotate(List[Tensor], [])
    _41 = self.encoders
    _42 = getattr(_41, "0")
    _43 = getattr(_41, "1")
    _44 = getattr(_41, "2")
    _45 = getattr(_41, "3")
    _46 = getattr(_41, "4")
    _47 = getattr(_41, "5")
    _48 = getattr(_41, "6")
    _49 = getattr(_41, "7")
    _50 = getattr(_41, "8")
    _51 = torch.__is__(elayers_output_cache0, None)
    if _51:
      attn_cache, elayers_output_cache3 = None, elayers_output_cache0
    else:
      elayers_output_cache4 = unchecked_cast(List[Tensor], elayers_output_cache0)
      attn_cache, elayers_output_cache3 = elayers_output_cache4[0], elayers_output_cache4
    _52 = torch.__is__(conformer_cnn_cache, None)
    if _52:
      cnn_cache, conformer_cnn_cache0 = None, conformer_cnn_cache
    else:
      conformer_cnn_cache1 = unchecked_cast(List[Tensor], conformer_cnn_cache)
      cnn_cache, conformer_cnn_cache0 = conformer_cnn_cache1[0], conformer_cnn_cache1
    _53 = (_42).forward(xs14, masks1, pos_emb0, attn_cache, cnn_cache, )
    xs16, _54, new_cnn_cache, = _53
    _55 = torch.append(r_elayers_output_cache, xs16)
    _56 = torch.append(r_conformer_cnn_cache, new_cnn_cache)
    _57 = torch.__is__(elayers_output_cache3, None)
    if _57:
      attn_cache0, elayers_output_cache5 = None, elayers_output_cache3
    else:
      elayers_output_cache6 = unchecked_cast(List[Tensor], elayers_output_cache3)
      attn_cache0, elayers_output_cache5 = elayers_output_cache6[1], elayers_output_cache6
    _58 = torch.__is__(conformer_cnn_cache0, None)
    if _58:
      cnn_cache0, conformer_cnn_cache2 = None, conformer_cnn_cache0
    else:
      conformer_cnn_cache3 = unchecked_cast(List[Tensor], conformer_cnn_cache0)
      cnn_cache0, conformer_cnn_cache2 = conformer_cnn_cache3[1], conformer_cnn_cache3
    _59 = (_43).forward(xs16, masks1, pos_emb0, attn_cache0, cnn_cache0, )
    xs17, _60, new_cnn_cache0, = _59
    _61 = torch.append(r_elayers_output_cache, xs17)
    _62 = torch.append(r_conformer_cnn_cache, new_cnn_cache0)
    _63 = torch.__is__(elayers_output_cache5, None)
    if _63:
      attn_cache1, elayers_output_cache7 = None, elayers_output_cache5
    else:
      elayers_output_cache8 = unchecked_cast(List[Tensor], elayers_output_cache5)
      attn_cache1, elayers_output_cache7 = elayers_output_cache8[2], elayers_output_cache8
    _64 = torch.__is__(conformer_cnn_cache2, None)
    if _64:
      cnn_cache1, conformer_cnn_cache4 = None, conformer_cnn_cache2
    else:
      conformer_cnn_cache5 = unchecked_cast(List[Tensor], conformer_cnn_cache2)
      cnn_cache1, conformer_cnn_cache4 = conformer_cnn_cache5[2], conformer_cnn_cache5
    _65 = (_44).forward(xs17, masks1, pos_emb0, attn_cache1, cnn_cache1, )
    xs18, _66, new_cnn_cache1, = _65
    _67 = torch.append(r_elayers_output_cache, xs18)
    _68 = torch.append(r_conformer_cnn_cache, new_cnn_cache1)
    _69 = torch.__is__(elayers_output_cache7, None)
    if _69:
      attn_cache2, elayers_output_cache9 = None, elayers_output_cache7
    else:
      elayers_output_cache10 = unchecked_cast(List[Tensor], elayers_output_cache7)
      attn_cache2, elayers_output_cache9 = elayers_output_cache10[3], elayers_output_cache10
    _70 = torch.__is__(conformer_cnn_cache4, None)
    if _70:
      cnn_cache2, conformer_cnn_cache6 = None, conformer_cnn_cache4
    else:
      conformer_cnn_cache7 = unchecked_cast(List[Tensor], conformer_cnn_cache4)
      cnn_cache2, conformer_cnn_cache6 = conformer_cnn_cache7[3], conformer_cnn_cache7
    _71 = (_45).forward(xs18, masks1, pos_emb0, attn_cache2, cnn_cache2, )
    xs19, _72, new_cnn_cache2, = _71
    _73 = torch.append(r_elayers_output_cache, xs19)
    _74 = torch.append(r_conformer_cnn_cache, new_cnn_cache2)
    _75 = torch.__is__(elayers_output_cache9, None)
    if _75:
      attn_cache3, elayers_output_cache11 = None, elayers_output_cache9
    else:
      elayers_output_cache12 = unchecked_cast(List[Tensor], elayers_output_cache9)
      attn_cache3, elayers_output_cache11 = elayers_output_cache12[4], elayers_output_cache12
    _76 = torch.__is__(conformer_cnn_cache6, None)
    if _76:
      cnn_cache3, conformer_cnn_cache8 = None, conformer_cnn_cache6
    else:
      conformer_cnn_cache9 = unchecked_cast(List[Tensor], conformer_cnn_cache6)
      cnn_cache3, conformer_cnn_cache8 = conformer_cnn_cache9[4], conformer_cnn_cache9
    _77 = (_46).forward(xs19, masks1, pos_emb0, attn_cache3, cnn_cache3, )
    xs20, _78, new_cnn_cache3, = _77
    _79 = torch.append(r_elayers_output_cache, xs20)
    _80 = torch.append(r_conformer_cnn_cache, new_cnn_cache3)
    _81 = torch.__is__(elayers_output_cache11, None)
    if _81:
      attn_cache4, elayers_output_cache13 = None, elayers_output_cache11
    else:
      elayers_output_cache14 = unchecked_cast(List[Tensor], elayers_output_cache11)
      attn_cache4, elayers_output_cache13 = elayers_output_cache14[5], elayers_output_cache14
    _82 = torch.__is__(conformer_cnn_cache8, None)
    if _82:
      cnn_cache4, conformer_cnn_cache10 = None, conformer_cnn_cache8
    else:
      conformer_cnn_cache11 = unchecked_cast(List[Tensor], conformer_cnn_cache8)
      cnn_cache4, conformer_cnn_cache10 = conformer_cnn_cache11[5], conformer_cnn_cache11
    _83 = (_47).forward(xs20, masks1, pos_emb0, attn_cache4, cnn_cache4, )
    xs21, _84, new_cnn_cache4, = _83
    _85 = torch.append(r_elayers_output_cache, xs21)
    _86 = torch.append(r_conformer_cnn_cache, new_cnn_cache4)
    _87 = torch.__is__(elayers_output_cache13, None)
    if _87:
      attn_cache5, elayers_output_cache15 = None, elayers_output_cache13
    else:
      elayers_output_cache16 = unchecked_cast(List[Tensor], elayers_output_cache13)
      attn_cache5, elayers_output_cache15 = elayers_output_cache16[6], elayers_output_cache16
    _88 = torch.__is__(conformer_cnn_cache10, None)
    if _88:
      cnn_cache5, conformer_cnn_cache12 = None, conformer_cnn_cache10
    else:
      conformer_cnn_cache13 = unchecked_cast(List[Tensor], conformer_cnn_cache10)
      cnn_cache5, conformer_cnn_cache12 = conformer_cnn_cache13[6], conformer_cnn_cache13
    _89 = (_48).forward(xs21, masks1, pos_emb0, attn_cache5, cnn_cache5, )
    xs22, _90, new_cnn_cache5, = _89
    _91 = torch.append(r_elayers_output_cache, xs22)
    _92 = torch.append(r_conformer_cnn_cache, new_cnn_cache5)
    _93 = torch.__is__(elayers_output_cache15, None)
    if _93:
      attn_cache6, elayers_output_cache17 = None, elayers_output_cache15
    else:
      elayers_output_cache18 = unchecked_cast(List[Tensor], elayers_output_cache15)
      attn_cache6, elayers_output_cache17 = elayers_output_cache18[7], elayers_output_cache18
    _94 = torch.__is__(conformer_cnn_cache12, None)
    if _94:
      cnn_cache6, conformer_cnn_cache14 = None, conformer_cnn_cache12
    else:
      conformer_cnn_cache15 = unchecked_cast(List[Tensor], conformer_cnn_cache12)
      cnn_cache6, conformer_cnn_cache14 = conformer_cnn_cache15[7], conformer_cnn_cache15
    _95 = (_49).forward(xs22, masks1, pos_emb0, attn_cache6, cnn_cache6, )
    xs23, _96, new_cnn_cache6, = _95
    _97 = torch.append(r_elayers_output_cache, xs23)
    _98 = torch.append(r_conformer_cnn_cache, new_cnn_cache6)
    _99 = torch.__is__(elayers_output_cache17, None)
    if _99:
      attn_cache7 = None
    else:
      elayers_output_cache19 = unchecked_cast(List[Tensor], elayers_output_cache17)
      attn_cache7 = elayers_output_cache19[8]
    _100 = torch.__is__(conformer_cnn_cache14, None)
    if _100:
      cnn_cache7 = None
    else:
      conformer_cnn_cache16 = unchecked_cast(List[Tensor], conformer_cnn_cache14)
      cnn_cache7 = conformer_cnn_cache16[8]
    _101 = (_50).forward(xs23, masks1, pos_emb0, attn_cache7, cnn_cache7, )
    xs24, _102, new_cnn_cache7, = _101
    _103 = torch.append(r_elayers_output_cache, xs24)
    _104 = torch.append(r_conformer_cnn_cache, new_cnn_cache7)
    if self.normalize_before:
      xs25 = (self.after_norm).forward(xs24, )
    else:
      xs25 = xs24
    _105 = (xs25, xs14, r_elayers_output_cache, r_conformer_cnn_cache)
    return _105
  def forward_chunk_by_chunk(self: __torch__.wenet.transformer.encoder.___torch_mangle_21.ConformerEncoder,
    xs: Tensor,
    decoding_chunk_size: int) -> Tuple[Tensor, Tensor]:
    if torch.gt(decoding_chunk_size, 0):
      pass
    else:
      ops.prim.RaiseException("Exception")
    if torch.gt(self.static_chunk_size, 0):
      _106 = True
    else:
      _106 = self.use_dynamic_chunk
    if _106:
      pass
    else:
      ops.prim.RaiseException("Exception")
    subsampling = self.embed.subsampling_rate
    context = torch.add(self.embed.right_context, 1)
    stride = torch.mul(subsampling, decoding_chunk_size)
    _107 = torch.mul(torch.sub(decoding_chunk_size, 1), subsampling)
    decoding_window = torch.add(_107, context)
    num_frames = torch.size(xs, 1)
    ys = torch.tensor([0.], dtype=ops.prim.dtype(xs), device=ops.prim.device(xs), requires_grad=False)
    _108 = torch.add(torch.sub(num_frames, context), 1)
    _109 = torch.__range_length(0, _108, stride)
    ys0 = ys
    conformer_cnn_cache: Optional[List[Tensor]] = None
    elayers_output_cache: Optional[List[Tensor]] = None
    subsampling_cache: Optional[Tensor] = None
    for _110 in range(_109):
      cur = torch.__derive_index(_110, 0, stride)
      end = ops.prim.min(torch.add(cur, decoding_window), num_frames)
      _111 = torch.slice(xs, 0, 0, 9223372036854775807, 1)
      chunk_xs = torch.slice(torch.slice(_111, 1, cur, end, 1), 2, 0, 9223372036854775807, 1)
      _112 = (self).forward_chunk(chunk_xs, subsampling_cache, elayers_output_cache, conformer_cnn_cache, )
      ys1, subsampling_cache3, elayers_output_cache20, conformer_cnn_cache17, = _112
      ys0, conformer_cnn_cache, elayers_output_cache, subsampling_cache = ys1, conformer_cnn_cache17, elayers_output_cache20, subsampling_cache3
    _113 = torch.size(ys0, 1)
    _114 = ops.prim.device(ys0)
    masks = torch.ones([1, _113], dtype=11, layout=None, device=_114, pin_memory=None)
    masks2 = torch.unsqueeze(masks, 1)
    return (ys0, masks2)
